#include <fstream>
#include <iostream>
#include <list>
#include <map>
#include <set>
#include <cstring>

using namespace std;

class Node {
    int endOfBuffer;

public:
    Node() {
        endOfBuffer = 0;
    }

    ~Node() {
        delete next;
    }

    Node *addToBuffer(char symbol) {
        if (endOfBuffer != 32) {
            buffer[endOfBuffer] = symbol;
            endOfBuffer++;
            return this;
        } else {
            Node *nextElement = new Node();
            nextElement->addToBuffer(symbol);
            next = nextElement;
            return nextElement;
        }
    }

    bool isBufferFull() {
        return (bool) buffer[32 - 1];
    }

    bool isLast() {
        return !isBufferFull();
    }

    int length() {
        return endOfBuffer;
    }

    Node *next;
    char buffer[32]{};
};

struct cmp_str
{
    bool operator()(char const *a, char const *b) const
    {
        return std::strcmp(a, b) < 0;
    }
};

void print_map(map<char *, int, cmp_str> m)
{
    for (auto const &pair: m) {
        std::cout << "{" << pair.first << ": " << pair.second << "}\n";
    }
}

int main() {
    ifstream file;
    file.open(R"(C:\coding\cplusplus\untitled\pg67730.txt)");
    if (!file.is_open()) {
        exit(1);
    }
    Node *element = new Node();
    Node *first = element;
    while (file.good()) {
        element = element->addToBuffer(file.get());
    }
    map<char *, int, cmp_str> dict;
    set<char> punctuation{'!', '%', '^', '&', '*', '(', ')', '-', '+', '=', '{', '}', '|', '~', '[', ']', '\\',
                               ';', ':', '"', '<', '>', '?', ',', '.', '#', ' ','\377','\n','_'};
    Node *current = first;
    char *word_key;
    char word_arr[30]{0};
    int k = 0;
    bool isItFirstLoop = true;
    while(!(current->isLast())) {
        if(!isItFirstLoop){
            current = current->next;
        }
        isItFirstLoop=false;
        for (int i = 0; i < current->length(); i++) {
            if (!punctuation.count(current->buffer[i])) {
                word_arr[k] = current->buffer[i];
                k++;
            } else {
                word_key = new char[sizeof(word_arr)];
                strcpy(word_key,word_arr);
                if(!dict.count(word_key))
                    dict.insert({word_key, 1});
                else
                    dict[word_key]+=1;
                memset(word_arr,0,sizeof(word_arr));
                k=0;
            }
        }
    }
    cout << dict.size();
    print_map(dict);
    return 0;
}